//
//  YouVerify_SDK.h
//  YouVerify_SDK
//
//  Created by Masud Onikeku on 29/04/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for YouVerify_SDK.
FOUNDATION_EXPORT double YouVerify_SDKVersionNumber;

//! Project version string for YouVerify_SDK.
FOUNDATION_EXPORT const unsigned char YouVerify_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YouVerify_SDK/PublicHeader.h>


