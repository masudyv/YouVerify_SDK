//
//  Extensions.swift
//  YouVerify
//
//  Created by Masud Onikeku on 21/04/2024.
//

import Foundation
import UIKit

extension UIView {
    
    func showSpinnerView(child:UIActivityIndicatorView) {
        // add the spinner view controller
        //addSubview(child)
        //child.view.frame = frame
        addSubview(child)
        child.centre(centerX: centerXAnchor, centreY: centerYAnchor)
        //backgroundColor = UIColor(white: 0, alpha: 0.7)
        //child.didMove(toParent: self)
        
        /*if let tabBar = tabBarController?.tabBar {
         let viewOverTabBar = UIView(frame: CGRect(x: 0, y: 0, width: tabBar.frame.width, height: tabBar.frame.height))
         viewOverTabBar.tag = 1234
         viewOverTabBar.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.6)
         tabBar.addSubview(viewOverTabBar)
         }*/
    }
    
    func removeSpinnerView(child:UIActivityIndicatorView){
        //child.willMove(toParent: nil)
        child.removeFromSuperview()
        //backgroundColor = UIColor(white: 0, alpha: 0.7)
        
        /*if let tabBar = tabBarController?.tabBar {
         for views in tabBar.subviews {
         if views.tag == 1234 {
         views.removeFromSuperview()
         }
         }
         }*/
    }
    
    func constraint (equalToTop: NSLayoutYAxisAnchor? = nil,
                     equalToBottom: NSLayoutYAxisAnchor? = nil,
                     equalToLeft: NSLayoutXAxisAnchor? = nil,
                     equalToRight: NSLayoutXAxisAnchor? = nil,
                     paddingTop: CGFloat = 0,
                     paddingBottom: CGFloat = 0,
                     paddingLeft: CGFloat = 0,
                     paddingRight: CGFloat = 0,
                     width: CGFloat? = nil,
                     height: CGFloat? = nil
    ) {
        
        translatesAutoresizingMaskIntoConstraints = false
        
        if let equalToTop = equalToTop {
            
            topAnchor.constraint(equalTo: equalToTop, constant: paddingTop).isActive = true
        }
        
        if let equalTobottom = equalToBottom {
            
            bottomAnchor.constraint(equalTo: equalTobottom, constant: -paddingBottom).isActive = true
        }
        
        if let equalToLeft = equalToLeft {
            
            leadingAnchor.constraint(equalTo: equalToLeft, constant: paddingLeft).isActive = true
        }
        
        if let equalToRight = equalToRight {
            
            trailingAnchor.constraint(equalTo: equalToRight, constant: -paddingRight).isActive = true
        }
        
        if let width = width {
            
            widthAnchor.constraint(equalToConstant: width).isActive = true
        }
        
        if let height = height {
            
            heightAnchor.constraint(equalToConstant: height).isActive = true
        }
    }
    
    
    func centre (centerX: NSLayoutXAxisAnchor? = nil, centreY: NSLayoutYAxisAnchor? = nil) {
        
        translatesAutoresizingMaskIntoConstraints = false
        
        if let centerx = centerX {
            
            centerXAnchor.constraint(equalTo: centerx).isActive = true
        }
        
        if let centery = centreY {
            
            centerYAnchor.constraint(equalTo: centery).isActive = true
        }
    }
    
    
    func removeProperly() {
        
        for view in self.subviews {
            
            view.removeFromSuperview()
        }
        self.removeFromSuperview()
    }
    
    func addCordinateSubviewToCentre(view : UIView, width : Double, height : Double) {
        
        view.frame = CGRect(x: (frame.width/2.0) - (width/2.0), y: (frame.height/2.0) - (height/2.0), width: width, height: width)
        addSubview(view)
        
    }
    
    func centreHorizontally(view : UIView, y : Double, height : Double, width: Double) {
        
        view.frame = CGRect(x: (frame.width/2.0) - (width/2.0), y: y, width: width, height: height)
        
        addSubview(view)
        
    }
    
    func centreVertically(view : UIView, x : Double, height : Double, width: Double) {
        
        view.frame = CGRect(x: x, y: (frame.height/2.0) - (height/2.0), width: width, height: height)
        
        addSubview(view)
        
    }
    
    func centerVertInSuperView(x: Double, height: Double) {
        
        frame.origin.y = (frame.height/2.0) - (height/2.0)
    }
}

extension UIViewController {
    
    func showAlert(msg: String) {
        
        let alert = UIAlertController(title: "Message", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Okay", style: .default))
        self.present(alert, animated: true)
    }
    
    func showAlert2(msg: String, actions: @escaping () -> Void) {
        
        let alert = UIAlertController(title: "Message", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: {action in
                
            actions()
        }))
        self.present(alert, animated: true)
    }
}

public extension UIFont {
    public static func register(from url: URL) throws {
        guard let fontDataProvider = CGDataProvider(url: url as CFURL) else {
            throw NSError(domain: "Could not create font data provider for \(url).", code: 0)
        }
        let font = CGFont(fontDataProvider)
        var error: Unmanaged<CFError>?
        guard CTFontManagerRegisterGraphicsFont(font!, &error) else {
            throw error!.takeUnretainedValue()
        }
    }
}

extension UIImage {
    
    public func mask(with color: UIColor) -> UIImage {
        
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        let context = UIGraphicsGetCurrentContext()!
        
        let rect = CGRect(origin: CGPoint.zero, size: size)
        
        color.setFill()
        self.draw(in: rect)
        
        context.setBlendMode(.sourceIn)
        context.fill(rect)
        
        let resultImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return resultImage
    }
    
}
