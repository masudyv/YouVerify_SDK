//
//  Observable.swift
//  YouVerify
//
//  Created by Masud Onikeku on 24/04/2024.
//

import Foundation

final class Observable<T> {
    
    var value : T {
        didSet {
            listener?(value)
        }
    }
    private var listener : ((T) -> Void)?
    
    init (_ value : T) {
        self.value = value
    }
    
    func bind(completion : @escaping (T) -> Void) {
        
        completion(value)
        listener = completion
    }
}

class Response {
    
    var check : Bool
    var description : String
    var object: Any?
    
    init(check : Bool, description : String, object : Any? = nil) {
        self.check = check
        self.description = description
        self.object = object
    }
}

struct JASON {
    static let encoder = JSONEncoder()
}

extension Encodable {
    subscript(key: String) -> Any? {
        return dictionary[key]
    }
    var dictionary: [String: Any] {
        return (try? JSONSerialization.jsonObject(with: JASON.encoder.encode(self))) as? [String: Any] ?? [:]
    }
}
