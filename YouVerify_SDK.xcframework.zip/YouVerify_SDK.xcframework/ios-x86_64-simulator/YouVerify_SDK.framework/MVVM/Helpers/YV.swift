//
//  YV.swift
//  YouVerify_SDK
//
//  Created by Masud Onikeku on 30/04/2024.
//

import Foundation
import UIKit

public class YV {
    
    let merchant_id : String
    let callBack: ([String:Any]?) -> Void
    
    public init(merchant_id: String, callBack: @escaping ([String:Any]?) -> Void) {
        self.merchant_id = merchant_id
        self.callBack = callBack
        merch_id = merchant_id
    }
    
    public func startYV(from context: UIViewController) {
        
        /*let bundle = Bundle(for: YV.self)
        let bundleurl = bundle.url(forResource: "YouVerify_SDK", withExtension: "bundle")
        let bd = Bundle(url: bundleurl!)*/
        
        let vc = YVStoryBoard.instantiateViewController(withIdentifier: "home") as! HomeViewController
        vc.callBack = callBack
        let nav = UINavigationController(rootViewController: vc)
        nav.hidesBarsOnTap = true
        nav.isNavigationBarHidden = true
        nav.modalPresentationStyle = .fullScreen
        context.present(nav, animated: true)
    }
}

protocol YVCallback {
    
    func addressCapture(captureData: [String:Any])
}
