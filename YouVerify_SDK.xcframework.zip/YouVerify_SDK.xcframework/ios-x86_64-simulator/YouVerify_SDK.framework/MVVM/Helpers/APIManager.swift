//
//  APIManager.swift
//  YouVerify
//
//  Created by Masud Onikeku on 24/04/2024.
//

import Foundation
import Alamofire
import SwiftyJSON



enum ApiResult {
    case success(Data)
    case failure(RequestError)
}

enum RequestError: Error {
    case unknownError(String)
    case connectionError
    case authorizationError(JSON)
    case invalidRequest
    case notFound
    case invalidResponse
    case serverError
    case serverUnavailable
}

class Service {
    
    static func requestDataWithHeaderwithFile  (url:String, method:HTTPMethod, parameters:[String : Any]?, arrImages:[(image: Data,name:String)]? = nil, completion: @escaping (ApiResult)->Void){
        
        let headers: HTTPHeaders = [
            
            .accept("application/json"),
            .contentType("multipart/form-data")
        ]
        
        AF.upload(multipartFormData: { multipartFormData in
            if let param = parameters{
                for (key,value) in param {
                    if !("\(value)").isEmpty {
                        print("parameters", "\(key) : \(value)")
                        multipartFormData.append("\(value)".data(using: .utf8)!, withName: key)
                    }
                    
                }
            }
            
            var i = 0
            
            if let images = arrImages {
                for data in images {
                    
                    multipartFormData.append(data.image, withName: "files",fileName: "\(data.name).jpg" , mimeType: "image/jpg")
                    i += 1
                }
            }
            //print("data: \(multipartFormData)")
            
        },to: uploadBaseUrl+url, usingThreshold:UInt64.init(),method: .post,headers: headers).response { response in
            
            if let value = response.value{
                let jsonResult = JSON(value)
                print("API:::::::::::::::>>>>>>>>>\(uploadBaseUrl + url)")
                print("Parameters:::::::::::::::>>>>>>>>>\(parameters!)")
                print("result:::::::::::::::>>>>>>>>>\(jsonResult)")
                completion(ApiResult.success(response.data!))
            }else{
                if let value = response.error{
                    completion(ApiResult.failure(.unknownError(value.errorDescription ?? "Unknown error")))
                }
            }
            
        }
        
    }
    
    static func requestData(url:String, method:HTTPMethod, parameters:[String : Any]?, completion: @escaping (ApiResult)->Void){
        
        AF.request(baseUrl + url, method: method, parameters: parameters, encoding: URLEncoding(), headers: nil).responseData(completionHandler: { (responseData) in
            
            if let value = responseData.value{
                let code = responseData.response!.statusCode
                
                if (200...299).contains(code) {
                    
                    let json = JSON(value)
                    print("API:::::::::::::::>>>>>>>>>\(baseUrl + url)")
                    print("Parameters:::::::::::::::>>>>>>>>>\(parameters!)")
                    print("result:::::::::::::::>>>>>>>>>\(json)")
                    completion(ApiResult.success(value))
                }else {
                    
                    let json = JSON(value)
                    print("API:::::::::::::::>>>>>>>>>\(baseUrl + url)")
                    print("Parameters:::::::::::::::>>>>>>>>>\(parameters!)")
                    print("result:::::::::::::::>>>>>>>>>\(json)")
                    let msg = (json["message"].stringValue != nil && json["message"].stringValue != "") ? json["message"].stringValue : "Error reading document"
                    completion(ApiResult.failure(RequestError.unknownError(msg)))
                }
                
                
            }else{
                if let value = responseData.error{
                    completion(ApiResult.failure(.unknownError(value.localizedDescription)))
                }
            }
            
        })
        
    }
    
    static func sessionDataWithHeaderwithFile  (url:String, method:HTTPMethod, parameters:[String : String]?, arrImages:[(image: Data,name:String)]? = nil, completion: @escaping (ApiResult)->Void){
        
        let headers: HTTPHeaders = [
            
            .accept("application/json"),
            .contentType("multipart/form-data")
        ]
        
        guard let requestURL = URL(string: uploadBaseUrl + url) else {
            return
        }
        
        // prepare request
        var request = URLRequest(url: requestURL)
        request.setValue("multipart/form-data", forHTTPHeaderField: "Content-Type")
        //request.allHTTPHeaderFields = header
        request.httpMethod = method.rawValue
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        // built data from img
        if let arrImgs = arrImages {
            
            /*var imm : [Data] = []
            for imgs in arrImgs {
                
                imm.append(imgs.image)
            }
            
            let data = try? NSKeyedArchiver.archivedData(withRootObject: imm, requiringSecureCoding: false)*/
            
            request.httpBody = createBodyWithParameters(parameters: parameters!, filePathKey: "files", imageDataKey: arrImgs, boundary: boundary, fileName: arrImgs.first!.name)
        }
        
        let task =  URLSession.shared.dataTask(with: request,
                                               completionHandler: { (data, _, error) -> Void in
            
            if let data = data {
                
                let json = JSON(data)
                print("API:::::::::::::::>>>>>>>>>\(uploadBaseUrl + url)")
                print("Parameters:::::::::::::::>>>>>>>>>\(parameters!)")
                print("image uploaded successfully \(json.dictionaryObject!)")
                if json["statusCode"].intValue == 200 || json["statusCode"].intValue == 201 {
                    completion(ApiResult.success(data))
                }else {
                    if json["message"].stringValue != "" {
                        
                        completion(ApiResult.failure(.unknownError(json["message"].stringValue)))
                    }else {
                        completion(ApiResult.failure(.unknownError("Error uploading image")))
                    }
                    
                }
                
                
            } else if let error = error {
                print(error.localizedDescription)
                completion(ApiResult.failure(.unknownError(error.localizedDescription)))
            }
        })
        task.resume()
        
    }
    
    static func generateBoundaryString() -> String {
        return "Boundary-\(Int.random(in: 1000 ... 9999))"
    }
    
    static func createBodyWithParameters(parameters: [String: String],
                                  
                                  filePathKey: String,
                                  imageDataKey: [(Data, String)],
                                         boundary: String, fileName: String) -> Data {
        
        let body = NSMutableData()
        let mimetype = "image/png"
        
        for imgs in imageDataKey {
            
            body.append("--\(boundary)\r\n".data(using: .utf8) ?? Data())
            
            body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(imgs.1)\"\r\n".data(using: .utf8) ?? Data())
            body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: .utf8) ?? Data())
            body.append(imgs.0)
            body.append("\r\n".data(using: .utf8) ?? Data())
        }
        
        body.append("--\(boundary)--\r\n".data(using: .utf8) ?? Data())
        
        
        
        return body as Data
    }
    
}
