//
//  Constants.swift
//  YouVerify
//
//  Created by Masud Onikeku on 22/04/2024.
//

import Foundation

enum CaptureType {
    case id
    case passport
    case anyid
}

var merch_id = ""
let baseUrl = "https://identity.dev.svc.youverify.co/"
let uploadBaseUrl = "https://cdn.svc.youverify.co/"

let bundle = Bundle(for: YV.self)
let bundleurl = bundle.url(forResource: "YouVerify_SDK", withExtension: "bundle")
let bd = Bundle(url: bundleurl!)
let YVStoryBoard = UIStoryboard(name: "Main", bundle: bd)

var fontUrl : [URL] = []
var boldFont : UIFont = UIFont.boldSystemFont(ofSize: 16)
var regFont : UIFont = UIFont.systemFont(ofSize: 12)

let yvBlue = UIColor(red: 70/255, green: 178/255, blue: 200/255, alpha: 1.0)
