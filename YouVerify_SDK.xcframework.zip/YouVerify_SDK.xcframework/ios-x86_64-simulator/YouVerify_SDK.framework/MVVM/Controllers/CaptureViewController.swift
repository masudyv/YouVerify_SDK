//
//  CaptureViewController.swift
//  YouVerify
//
//  Created by Masud Onikeku on 17/04/2024.
//

import UIKit
import AVFoundation
import MLKitBarcodeScanning
import MLKitVision
import MLKitCommon



class CaptureViewController: UIViewController {
    
    @IBOutlet weak var closeImage: UIImageView!
    
    @IBOutlet weak var boundedImage: UIImageView!
    var captureSession: AVCaptureSession!
    var videoOutput: AVCapturePhotoOutput?
    var videoInput: AVCaptureDeviceInput?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    var captureDevice: AVCaptureDevice?
    var session: AVCaptureDevice.DiscoverySession?
    var captureDeviceVideoFound: Bool = false
    var scans : [UIImage] = []
    var type : CaptureType? = nil
    @IBOutlet weak var captureImage: UIImageView!
    @IBOutlet weak var faceInstruction: UILabel!
    @IBOutlet weak var scanView: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        initSessions()
    }
    
    func setup() {
        
        closeImage.isUserInteractionEnabled = true
        closeImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(close)))
        
        captureImage.isUserInteractionEnabled = true
        captureImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(capturePhoto)))
        
        self.view.backgroundColor = .white
        
        self.scanView.strokeBorder()
        
        self.processData(img: UIImage(named: "cardImage")!)
    }
    
    @objc func close() {
        
        self.dismiss(animated: true)
    }
    
    @objc func capturePhoto() {
        
        var photoSettings = AVCapturePhotoSettings()


        // Capture HEIF photos when supported.
        if self.videoOutput!.availablePhotoCodecTypes.contains(AVVideoCodecType.hevc) {
            photoSettings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.hevc])
        } else {
            photoSettings = AVCapturePhotoSettings()
        }


        // Set the flash to auto mode.
        if self.captureDevice!.isFlashAvailable {
            photoSettings.flashMode = .auto
        }


        // Enable high-resolution photos.
        //photoSettings.maxPhotoDimensions = self.videoOutput!.maxPhotoDimensions
        if !photoSettings.availablePreviewPhotoPixelFormatTypes.isEmpty {
            photoSettings.previewPhotoFormat = [kCVPixelBufferPixelFormatTypeKey as String: photoSettings.__availablePreviewPhotoPixelFormatTypes.first!]
        }
        
        //photoSettings.photoQualityPrioritization = self.photoQualityPrioritizationMode
        
        self.videoOutput?.capturePhoto(with: photoSettings, delegate: self)
    }
    
    func initSessions() {
        
        captureSession = AVCaptureSession()
        //captureSession.sessionPreset = .medium
        session = AVCaptureDevice.DiscoverySession.init(deviceTypes:[.builtInWideAngleCamera], mediaType: AVMediaType.video, position: AVCaptureDevice.Position.unspecified)
        captureDevice = session?.devices.compactMap{$0}.filter {
            $0.position == AVCaptureDevice.Position.back
        }.first
        let devices = session?.devices
        do {
            try captureDevice?.lockForConfiguration()
            captureDevice?.isFocusModeSupported(.continuousAutoFocus)
            captureDevice?.unlockForConfiguration()
        } catch  {
            print(error.localizedDescription)
        }
        captureDeviceVideoFound = true
        startSession()
    }
    
    func startSession() {
        
        if captureDevice == nil {
            let devices = (session?.devices.compactMap{$0})
            for device in devices! {
                
                if (device.hasMediaType(AVMediaType.video)) {
                    
                    captureDevice = device as? AVCaptureDevice //initialize video
                    if captureDevice != nil {
                        print("Capture device found")
                        captureDeviceVideoFound = true;
                    }
                    
                }
            }
        }
        
        do {
            videoInput = try AVCaptureDeviceInput(device: captureDevice!)
            self.videoOutput = AVCapturePhotoOutput()
            //print(self.videoOutput?.outputFileURL)
            let audioDevice = AVCaptureDevice.default(for: AVMediaType.audio)
            let audioInput = try AVCaptureDeviceInput(device: audioDevice!)
            
            if captureSession.canAddInput(videoInput!) && captureSession.canAddOutput(videoOutput!) {
                captureSession.addInput(videoInput!)
                captureSession.addOutput(videoOutput!)
                setupLivePreview()
            }
            //Step 9
        }
        catch let error  {
            print("Error Unable to initialize back camera:  \(error.localizedDescription)")
        }
        DispatchQueue.global(qos: .userInitiated).async { //[weak self] in
            
            if(self.captureDeviceVideoFound){
                
                self.captureSession.startRunning()
            }else {
                print("video input not found")
            }
            //Step 13
        }
        DispatchQueue.main.async {
            self.videoPreviewLayer.frame = (UIScreen.main.bounds)
        }
        
    }
    
    func setupLivePreview() {
        
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        //videoPreviewLayer.backgroundColor = UIColor.black.withAlphaComponent(0.7).cgColor
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.connection?.videoOrientation = .portrait
        //videoPreviewLayer.masksToBounds = true
        self.scanView.layer.masksToBounds = true
        videoPreviewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        //videoPreviewLayer.frame = self.scanView.layer.bounds
        //videoPreviewLayer.frame = CGRect(x: 12, y: (UIScreen.main.bounds.height - 300) / 2, width: UIScreen.main.bounds.width - 24, height: 300)
        //self.view.frame = CGRect(x: 12, y: (UIScreen.main.bounds.height - 300) / 2, width: UIScreen.main.bounds.width - 24, height: 300)
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        //self.scanView.layer.insertSublayer(videoPreviewLayer, at: 0)
        self.scanView.layer.addSublayer(videoPreviewLayer)
        
        //addCameraLayerAndScanLayer()
        
        //Step12
    }
    
    private func addCameraLayerAndScanLayer(){
        // Draw a graphics with a mostly solid alpha channel
        // and a square of "clear" alpha in there.
        UIGraphicsBeginImageContext(self.view.bounds.size)
        let cgContext = UIGraphicsGetCurrentContext()
        cgContext?.fill(self.view.bounds)
        cgContext?.clear(CGRect(x:self.scanView.frame.origin.x, y:self.scanView.frame.origin.y, width: self.scanView.bounds.width , height: self.scanView.bounds.height ))
        let maskImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        // Set the content of the mask view so that it uses our
        // alpha channel image
        let maskView = UIView(frame: self.view.bounds)
        view.layer.contents = maskImage?.cgImage
        self.view.mask = maskView
    }


}

extension CaptureViewController : AVCapturePhotoCaptureDelegate {
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            print(error)
        }else {
            
            guard let imageData = photo.fileDataRepresentation() else { return }
            let image = UIImage(data: imageData)
            if let img = image {
                if self.type == CaptureType.id {
                    self.scans.append(img)
                    
                    //self.scans.append(img)
                }else {
                    self.scans.append(img)
                }
            }
            
            if self.type == CaptureType.id {
                if scans.count < 2 {
                    
                    faceInstruction.text = "Scan back of card"
                }else {
                    //process photo
                    //self.dismiss(animated: true)
                    mergeImages()
                    processData(img: self.scans.last!)
                }
            }else {
                
                //showCapture()
                processData(img: self.scans.first!)
            }
        }
    }
    
    func mergeImages() {
        
        var bottomImage = scans.last!
        var topImage = scans.first!

        var size = CGSize(width: UIScreen.main.bounds.width - 64.0, height: 530.0)
        UIGraphicsBeginImageContext(size)

        let areaSize1 = CGRect(x: 0, y: 0, width: size.width, height:250)
        let areaSize2 = CGRect(x: 0, y: 280, width: size.width, height: 250)
        topImage.draw(in: areaSize1)

        bottomImage.draw(in: areaSize2, blendMode: .normal, alpha: 0.8)

        var newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        let image = UIImageView(image: newImage)
        image.backgroundColor = .white
        image.contentMode = .scaleAspectFill
        image.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        self.videoPreviewLayer.removeFromSuperlayer()
        
        for view in self.view.subviews {
            if view != closeImage {
                closeImage.tintColor = .black
                view.removeProperly()
            }
            
        }
        self.view.backgroundColor = .white
        self.view.addCordinateSubviewToCentre(view: image, width: size.width, height: size.height)
    
        UIGraphicsEndImageContext()
    }
    
    func cropImage(image: UIImage, to aspectRatio: CGFloat,completion: @escaping (UIImage) -> ()) {
        DispatchQueue.global(qos: .background).async {
            let imageAspectRatio = image.size.height/image.size.width
            var newSize = image.size
            if imageAspectRatio > aspectRatio {
                newSize.height = image.size.width * aspectRatio
            } else if imageAspectRatio < aspectRatio {
                newSize.width = image.size.height / aspectRatio
            } else {
                completion (image)
            }
            let center = CGPoint(x: image.size.width/2, y: image.size.height/2)
            let origin = CGPoint(x: center.x - newSize.width/2, y: center.y - newSize.height/2)
            let cgCroppedImage = image.cgImage!.cropping(to: CGRect(origin:      origin, size: CGSize(width: newSize.width, height: newSize.height)))!
            let croppedImage = UIImage(cgImage: cgCroppedImage, scale: image.scale, orientation: image.imageOrientation)
            completion(croppedImage)
        }
    }
    
    func showCapture() {
        
        var topImage = scans.first!
        let image = UIImageView(image: topImage)
        image.backgroundColor = .white
        image.contentMode = .scaleAspectFit
        image.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width - 64.0, height: 530.0)
        self.videoPreviewLayer.removeFromSuperlayer()
        
        for view in self.view.subviews {
            if view != closeImage {
                closeImage.tintColor = .black
                view.removeProperly()
            }
            
        }
        self.view.backgroundColor = .white
        self.view.addCordinateSubviewToCentre(view: image, width: UIScreen.main.bounds.width - 64.0, height: 530.0)
    }
    
    func processData(img: UIImage) {
        
        let barcodeOptions = BarcodeScannerOptions(formats: BarcodeFormat.all)
        let visionImage = VisionImage(image: img) //VisionImage(image: img)
        visionImage.orientation = img.imageOrientation
        let barcodeScanner = BarcodeScanner.barcodeScanner()
        
        barcodeScanner.process(visionImage) { features, error in
            print("barcodes", features)
          guard error == nil, let features = features, !features.isEmpty else {
            // Error handling
              print(error)
            return
          }
          // Recognized barcodes
           
            
            for barcode in features {
                let corners = barcode.cornerPoints
                
                let displayValue = barcode.displayValue
                let rawValue = barcode.rawValue
                
                let valueType = barcode.valueType
                print("corners", corners)
                print("displayValue", displayValue)
                print("rawValue", rawValue)
                print("valueType", valueType)
                //print("\n")
                switch valueType {
                case .driversLicense:
                    let name = barcode.driverLicense?.documentType
                case .URL:
                    let title = barcode.url!.title
                    let url = barcode.url!.url
                default:
                    // See API reference for all supported value types
                    print(valueType)
                }
            }
            
            if !features.isEmpty {
                print("barcodes data", features.first!.rawData)
                let dt = features.first!.rawData
                let data = try? JSONSerialization.jsonObject(with: dt!)
                //print("decoded data", data!)
                
                if let data = data as? [String : String] {
                    let label = UILabel()
                    label.text = data.description
                    label.numberOfLines = 0
                    label.textColor = .black
                    label.font = UIFont.systemFont(ofSize: 12)
                    self.videoPreviewLayer.removeFromSuperlayer()
                    
                    for view in self.view.subviews {
                        if view != self.closeImage {
                            self.closeImage.tintColor = .black
                            view.removeProperly()
                        }
                        
                    }
                    self.view.backgroundColor = .white
                    self.view.addSubview(label)
                    label.constraint(equalToLeft: self.view.leadingAnchor, equalToRight: self.view.trailingAnchor, paddingLeft: 12, paddingRight: 12)
                    label.centre(centreY: self.view.centerYAnchor)
                }
            } else {
                
                let alert = UIAlertController(title: "Message", message: "Document has no detectable barcode", preferredStyle: .alert)
            }
        }
    }
}

extension CaptureViewController: AVCaptureFileOutputRecordingDelegate  {
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        
        if let err = error {
            
            print(error?.localizedDescription)
        }else {
            
            print(outputFileURL)
            /*let image = generateThumbnail(path: outputFileURL)
            if let img = image {
                self.scans.append(img)
            }*/
            if scans.count < 2 {
                
                faceInstruction.text = "Scan back of card"
            }else {
                //process photo
                self.dismiss(animated: true)
            }
        }
    }
    
    /*func generateThumbnail(path: URL) -> UIImage? {
        do {
            
            let asset = AVAsset(url: path)
            //print(p.path  + "\n" + path)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = true
            let cgImage = try generator.copyCGImage(at: CMTimeMake(value: 0, timescale: 1), actualTime: nil)
            let thumbnail = UIImage(cgImage: cgImage)
            return thumbnail
        } catch let error {
            print("*** Error generating thumbnail: \(error.localizedDescription)")
            return nil
        }
    }*/
    
   
}

extension UIView {
    
    func strokeBorder() {
        self.backgroundColor = .clear
        self.clipsToBounds = true
        self.layer.cornerRadius = 12
        self.layer.borderWidth = 10
        self.layer.borderColor = UIColor.white.cgColor
    }
}


