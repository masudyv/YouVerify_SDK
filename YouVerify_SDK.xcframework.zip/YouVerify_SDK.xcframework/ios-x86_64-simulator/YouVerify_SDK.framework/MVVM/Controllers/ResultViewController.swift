//
//  ResultViewController.swift
//  YouVerify
//
//  Created by Masud Onikeku on 24/04/2024.
//

import UIKit
import MLKitBarcodeScanning
import MLKitVision
import MLKitCommon
import SKCountryPicker
import SwiftyJSON

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var resultStack: UIStackView!
    @IBOutlet weak var firstNameLabel: UILabel!
    var closeButton = UIButton()
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var middleName: UILabel!
    @IBOutlet weak var city: UILabel!
    @IBOutlet weak var state: UILabel!
    @IBOutlet weak var zip: UILabel!
    @IBOutlet weak var street: UILabel!
    @IBOutlet weak var dob: UILabel!
    @IBOutlet weak var documentType: UILabel!
    @IBOutlet weak var expiryDate: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var country: UILabel!
    @IBOutlet weak var issuingDate: UILabel!
    @IBOutlet weak var licenseNumber: UILabel!
    
    
    @IBOutlet weak var resultClose: UIButton!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var resultStatus: UILabel!
    @IBOutlet weak var resultDescription: UILabel!
    @IBOutlet weak var resultView: UIView!
    var resStatus = true
    
    
    var images : [UIImage] = []
    var imgs : [(Data, String)]? = nil
    var county: Country? = nil
    var type : CaptureType? = nil
    let viewModel = CaptureViewModel()
    var backView = UIView()
    var docuType = ""
    var imageLinks : [String : String] = [:]
    var docu_cap_body : [String : Any] = [:]
    var barScanned = false
    var result : [String : Any]? = [:]
    var callBack: (([String:Any]?) -> Void)? = nil
    var lbl = UILabel()
    
    var dobText = ""
    var expiry = ""
    var issue = ""
    var genderText = ""
    var firstName = ""
    var lastName = ""
    var midName = ""
    var fullName = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        binds()
        setup()
        imgs = self.images.map({img -> (Data, String) in
            
            if img == self.images.first {
                return (img.jpegData(compressionQuality: 0.1)!, "frontImgData")
            }else {
                return (img.jpegData(compressionQuality: 0.1)!, "backImgData")
            }
        })
        
        if type == CaptureType.id {
            processData(img: self.images.last!)
            
            //let imag = UIImage(named: "lcard")
            //processData(img: imag!)
            
        }else if type == CaptureType.passport {
            
            self.docuType = "passport"
            showLoader()
            viewModel.uploadImage(body: ["expireInDays" : "30"], dataArray: imgs!)
            //self.callOcrApi(docType: "passport")
        }else {
            self.docuType = ""
            showLoader()
            viewModel.uploadImage(body: ["expireInDays" : "30"], dataArray: imgs!)
        }
        
        
        
        
    }
    
    func setup() {
        
        self.lbl.text = ""
        lbl.textColor = .black
        lbl.font = regFont
        lbl.numberOfLines = 0
        
        resultClose.layer.cornerRadius = 12
        
    }
    
    func callOcrApi(docType: String) {
        
        DispatchQueue.main.async {
            self.showLoader()
            //[(image,"image",url)]
            if self.type != CaptureType.id {
                for image in self.images {
                    
                    let img = UIImageView(image: image)
                    img.constraint(height: 250)
                    self.resultStack.addArrangedSubview(img)
                }
            }
            
            self.resultStack.addArrangedSubview(self.lbl)
            self.addCloseButton()
        }
        
        self.docuType = docType
        var body : [String : Any] = ["publicMerchantID" : merch_id, "documentType" : self.docuType, "frontImgData" : imageLinks["frontImgData"] ?? ""]
        if self.type != CaptureType.passport {
            
            body["countryCode"] = county?.countryCode ?? "ZA"
        }
        //UIPasteboard.general.string = imgs.first!.0
        if imgs!.count > 1 {
            body["backImgData"] = imageLinks["backImgData"]
        }
        //print(body)
        viewModel.sendComms(body: body)
    }
    
    func binds() {
        
        viewModel.uploadDone.bind(completion: {[weak self] res in
            
            DispatchQueue.main.async {
                self?.backView.removeProperly()
            }
            if let result = res {
                
                if result.check {
                    
                    if let res = result.object as? JSON {
                        var ress = res["data"].dictionaryObject
                        guard var ress = ress else {return}
                        if let expiry = ress["dateOfExpiry"] as? String {
                            ress["dateOfExpiry"] = self!.formatServerDate(date: expiry)
                        }
                        if let expiry = ress["dateOfBirth"] as? String {
                            ress["dateOfBirth"] = self!.formatServerDate(date: expiry)
                        }
                        if let expiry = ress["dateOfIssue"] as? String {
                            ress["dateOfIssue"] = self!.formatServerDate(date: expiry)
                        }
                        self!.result = ress
                        //self!.firstNameLabel.text = dvalue
                        var text = ""
                        
                        for (keys,value) in ress {
                            if let value = value as? String, value != "", keys != "fullDocumentBackImage", keys != "fullDocumentFrontImage" {
                                text = text + "\n\(keys): \(value)"
                            }
                        }
                        DispatchQueue.main.async {
                            self!.firstNameLabel.numberOfLines = 0
                            //self!.firstNameLabel.text = text
                            self?.firstNameLabel.font = regFont
                            //var lbl = UILabel()
                            //self?.lbl = self!.firstNameLabel
                            self?.lbl.text = text
                            //self?.resultStack.addArrangedSubview(lbl)
                        }
                        self!.resStatus = true
                    }
                }else {
                    
                    DispatchQueue.main.async {
                        self!.showAlert(msg: result.description)
                    }
                    self!.resStatus = false
                }
            }
        })
        
        viewModel.postCaptureDone.bind(completion: {[weak self] res in
            
            DispatchQueue.main.async {
                self?.backView.removeProperly()
            }
            if let result = res {
                
                if result.check {
                    
                    if let res = result.object as? JSON {
                        var ress = res["data"].dictionaryObject
                        guard var ress = ress else {return}
                        //ress!["dvd"] = self!.formatServerDate(date: "dvd")
                        if let expiry = ress["dateOfExpiry"] {
                            ress["dateOfExpiry"] = self!.formatServerDate(date: expiry as! String)
                        }
                        if let expiry = ress["dateOfBirth"] {
                            ress["dateOfBirth"] = self!.formatServerDate(date: expiry as! String)
                        }
                        if let expiry = ress["dateOfIssue"] {
                            ress["dateOfIssue"] = self!.formatServerDate(date: expiry as! String)
                        }
                        self!.result = ress
                        var text = ""
                        
                        for (keys,value) in ress {
                            if let value = value as? String, value != "", keys != "fullDocumentBackImage", keys != "fullDocumentFrontImage" {
                                text = text + "\n\(keys): \(value)"
                            }
                        }
                        DispatchQueue.main.async {
                            //self!.firstNameLabel.text = text
                        }
                        self!.resStatus = true
                    }
                }else {
                    DispatchQueue.main.async {
                        self!.showAlert(msg: result.description)
                    }
                    self!.resStatus = false
                }
            }
        })
        
        viewModel.fileUploadDone.bind(completion: {[weak self] res in
            
            DispatchQueue.main.async {
                self?.backView.removeProperly()
            }
            if let result = res {
                
                if result.check {
                    
                    if let captures = result.object as? [[String : Any]] {
                        
                        for cap in captures {
                            
                            self?.imageLinks[cap["originalname"] as! String] = cap["location"] as! String
                        }
                        if self?.type == CaptureType.id {
                            if self!.barScanned {
                                self!.docu_cap_body["fullDocumentFrontImage"] = self!.imageLinks["frontImgData"]
                                self!.docu_cap_body["fullDocumentBackImage"] = self!.imageLinks["backImgData"]
                                self!.viewModel.sendPostCapture(body: self!.docu_cap_body)
                            }else {
                                self?.callOcrApi(docType: "id_card")
                            }
                        }else if self?.type == CaptureType.passport {
                            self?.callOcrApi(docType: "passport")
                        }else {
                            self?.callOcrApi(docType: "id_card")
                        }
                    }
                }else {
                    DispatchQueue.main.async {
                        self!.showAlert(msg: result.description)
                    }
                }
            }
        })
    }
    
    func formatServerDate(date: String) -> String {
        
        let serverFormat = DateFormatter()
        serverFormat.dateFormat = "yyyy-MM-dd'T'hh:mm:ss.SSSZ"
        let serverDate = serverFormat.date(from: date)
        
        let usableFormat = DateFormatter()
        usableFormat.dateFormat = "dd-MM-yyyy"
        let usableDate = usableFormat.string(from: serverDate!)
        
        return usableDate
    }
    
    @IBAction func closeAction(_ sender: UIButton) {
        
        closeSdk()
        
    }
    
    func addCloseButton() {
        
        closeButton.setTitle("Proceed", for: .normal)
        closeButton.titleLabel?.font = boldFont
        closeButton.backgroundColor = yvBlue
        closeButton.layer.cornerRadius = 12
        closeButton.constraint(height: 45)
        closeButton.addTarget(self, action: #selector(proceedToResult), for: .touchUpInside)
        
        resultStack.addArrangedSubview(closeButton)
    }
    
    @objc func proceedToResult() {
        
        showResult()
    }
    
    
    func closeSdk() {
        
        self.navigationController!.dismiss(animated: true, completion: {
            
            if let callBack = self.callBack {
                callBack(self.result)
            }
        })
    }
    
    func showResult() {
        
        resultStatus.font = boldFont
        resultDescription.font = regFont
        
        if resStatus {
            resultView.alpha = 1
        }else {
            let image = UIImage(systemName: "xmark.circle.fill")
            image?.mask(with: .red)
            resultImage.tintColor = .red
            resultImage.image = image
            
            resultStatus.text = "Failed"
            resultDescription.text = "Your ID Capture has failed, please try again."
            resultView.alpha = 1
        }
    }

    func processData(img: UIImage) {
        
        let barcodeOptions = BarcodeScannerOptions(formats: [BarcodeFormat.PDF417, BarcodeFormat.aztec, BarcodeFormat.qrCode])
        let visionImage = VisionImage(image: img) //VisionImage(image: img)
        visionImage.orientation = img.imageOrientation
        let barcodeScanner = BarcodeScanner.barcodeScanner(options: barcodeOptions)
        
        barcodeScanner.process(visionImage) { [weak self] features, error in
            print("barcodes", features!)
          guard error == nil, let features = features, !features.isEmpty else {
            // Error handling
              print(error)
              //self!.showLoader()
              self!.docuType = "id_card"
              CountryPickerWithSectionViewController.presentController(on: self!, configuration: { countryController in
                  countryController.configuration.flagStyle = .circular
                  countryController.configuration.isCountryFlagHidden = false
                  countryController.configuration.isCountryDialHidden = false
                  countryController.favoriteCountriesLocaleIdentifiers = ["NG", "IN", "US", "ZA"]
                  
              }) { [weak self] country in
                  
                  guard let self = self else { return }
                  self.county = country
                  showLoader()
                  viewModel.uploadImage(body: ["expireInDays" : "30"], dataArray: imgs!)
                  //self.callOcrApi(docType: "id_card")
              }
              
            return
          }
          // Recognized barcodes
           
            
            for barcode in features {
                let corners = barcode.cornerPoints
                
                let displayValue = barcode.displayValue
                let rawValue = barcode.rawValue
                
                let valueType = barcode.valueType
                //BarcodeValueType.
                print("corners", corners)
                print("displayValue", displayValue)
                print("rawValue", rawValue)
                print("valueType", valueType.rawValue)
                //print("\n")
                switch valueType {
                case .driversLicense:
                    //self!.firstNameLabel.text = barcode.driverLicense?.firstName
                
                    var text = ""
                    var nameText = ""
                    if barcode.driverLicense!.firstName != "" && barcode.driverLicense!.firstName != nil {
                        nameText = "\nFirst Name: \(barcode.driverLicense!.firstName!)"
                    }
                    if barcode.driverLicense!.middleName != "" && barcode.driverLicense!.middleName != nil {
                        nameText = "\nMiddle Name: \(barcode.driverLicense!.middleName!)"
                    }
                    if barcode.driverLicense!.firstName == "" && barcode.driverLicense!.middleName == "" {
                        if barcode.driverLicense?.lastName != "" {
                            let names = barcode.driverLicense?.lastName!.split(separator: " ")
                            
                        }
                        nameText = "\nFull Name: \(barcode.driverLicense!.lastName!)"
                        
                    }else {
                        nameText = "\nLast Name: \(barcode.driverLicense!.lastName!)"
                    }
                    
                    if barcode.driverLicense!.addressCity != "" && barcode.driverLicense!.addressCity != nil {
                        nameText = nameText + "\nCity: \(barcode.driverLicense!.addressCity!)"
                    }
                    if barcode.driverLicense!.addressState != "" && barcode.driverLicense!.addressState != nil {
                        nameText = nameText + "\nState: \(barcode.driverLicense!.addressState!)"
                    }
                    if barcode.driverLicense!.addressZip != "" && barcode.driverLicense!.addressZip != nil {
                        nameText = nameText + "\nZip: \(barcode.driverLicense!.addressZip!)"
                    }
                    if barcode.driverLicense!.addressStreet != "" && barcode.driverLicense!.addressStreet != nil {
                        nameText = nameText + "\nStreet: \(barcode.driverLicense!.addressStreet!)"
                    }
                    if barcode.driverLicense!.birthDate != "" && barcode.driverLicense!.birthDate != nil {
                        //nameText = nameText + "\nBirth Date: \(barcode.driverLicense!.birthDate!)"
                        let dob = barcode.driverLicense!.birthDate!
                        var i = 0
                        var db = ""
                        for char in dob {
                            
                            if i == 1 || i == 3 {
                                db = db + String(char) + "-"
                            }else {
                               db = db + String(char)
                            }
                            i = i + 1
                        }
                        self?.dobText = self!.formatDate(date: db)
                        nameText = nameText + "\nBirth Date: \(db)"
                    }
                    if barcode.driverLicense!.documentType != "" && barcode.driverLicense!.documentType != nil {
                        nameText = nameText + "\nDocument Type: Driver's License"
                    }
                    if barcode.driverLicense!.expiryDate != "" && barcode.driverLicense!.expiryDate != nil {
                        //nameText = nameText + "\nExpiry Date: \(barcode.driverLicense!.expiryDate!)"
                        let dob = barcode.driverLicense!.expiryDate!
                        var i = 0
                        var db = ""
                        for char in dob {
                            
                            if i == 1 || i == 3 {
                                db = db + String(char) + "-"
                            }else {
                               db = db + String(char)
                            }
                            i = i + 1
                        }
                        self?.expiry = self!.formatDate(date: db)
                        nameText = nameText + "\nExpiry Date: \(db)"
                        
                    }
                    if barcode.driverLicense!.gender != "" && barcode.driverLicense!.gender != nil {
                        self!.genderText = barcode.driverLicense!.gender! == "1" ? "Male" : "Female"
                        nameText = nameText + "\nGender: \(barcode.driverLicense!.gender! == "1" ? "Male" : "Female")"
                    }
                    if barcode.driverLicense!.issuingCountry != "" && barcode.driverLicense!.issuingCountry != nil {
                        nameText = nameText + "\nCountry: \(barcode.driverLicense!.issuingCountry!)"
                    }
                    if barcode.driverLicense!.issuingDate != "" && barcode.driverLicense!.issuingDate != nil {
                        //nameText = nameText + "\nIssue Date: \(barcode.driverLicense!.issuingDate!)"
                        let dob = barcode.driverLicense!.issuingDate!
                        var i = 0
                        var db = ""
                        for char in dob {
                            
                            if i == 1 || i == 3 {
                                db = db + String(char) + "-"
                            }else {
                               db = db + String(char)
                            }
                            i = i + 1
                        }
                        self?.issue = self!.formatDate(date: db)
                        nameText = nameText + "\nIssue Date: \(db)"
                    }
                    if barcode.driverLicense!.licenseNumber != "" && barcode.driverLicense!.licenseNumber != nil {
                        nameText = nameText + "\nLicense Number: \(barcode.driverLicense!.licenseNumber!)"
                    }
                
                    //print(nameText)
                    self!.firstNameLabel.numberOfLines = 0
                    //self!.firstNameLabel.text = nameText
                    self?.firstNameLabel.font = regFont
                    
                    //self?.lbl = self!.firstNameLabel
                    self?.lbl.text = nameText
                    
                
                    let imgs = self!.images.map({img -> (Data, String) in
                        
                        if img == self!.images.first {
                            return (img.jpegData(compressionQuality: 0.4)!, "frontImgData")
                        }else {
                            return (img.jpegData(compressionQuality: 0.4)!, "backImgData")
                        }
                    })
                    
                    self!.showLoader()
                    self!.docu_cap_body = ["publicMerchantID" : merch_id, "documentType" : "drivers_license", "firstName" : barcode.driverLicense!.firstName ?? "", "lastName" : barcode.driverLicense!.lastName ?? "", "middleName" : barcode.driverLicense!.middleName ?? "", "fullName" : barcode.driverLicense!.lastName ?? "", "dateOfBirth" : self!.dobText, "dateOfExpiry" : self!.expiry, "dateOfIssue" : self!.issue, "documentNumber" : barcode.driverLicense!.licenseNumber ?? "", "gender" : self!.genderText, "address" : barcode.driverLicense!.addressStreet ?? "", "components" : "id_capture"]
                    self!.barScanned = true
                    self!.viewModel.uploadImage(body: ["expireInDays" : "30"], dataArray: self!.imgs!)
                    //self!.viewModel.sendPostCapture(body: self!.docu_cap_body)
                    
                case .URL:
                    let title = barcode.url!.title
                    let url = barcode.url!.url
                default:
                    // See API reference for all supported value types
                    print(valueType.rawValue)
                }
                
                if barcode.valueType != BarcodeValueType.driversLicense {
                    if let dvalue = barcode.displayValue {
                        //self!.firstNameLabel.text = dvalue
                        //self!.viewModel.uploadImage(body: ["expireInDays" : "30"], dataArray: self!.imgs!)
                        
                        self!.docuType = "id_card"
                        CountryPickerWithSectionViewController.presentController(on: self!, configuration: { countryController in
                            countryController.configuration.flagStyle = .circular
                            countryController.configuration.isCountryFlagHidden = false
                            countryController.configuration.isCountryDialHidden = false
                            countryController.favoriteCountriesLocaleIdentifiers = ["NG", "IN", "US", "ZA"]
                            
                        }) { [weak self] country in
                            
                            guard let self = self else { return }
                            self.county = country
                            self.showLoader()
                            self.viewModel.uploadImage(body: ["expireInDays" : "30"], dataArray: imgs!)
                            //self.callOcrApi(docType: "id_card")
                        }
                    }
                }
                
                print("rawValue", barcode.rawValue)
                print("format", barcode.format)
                
            }
            
            /*if !features.isEmpty {
                print("barcodes data", features.first!.rawData)
                let dt = features.first!.rawData
                let data = try? JSONSerialization.jsonObject(with: dt!)
                //print("decoded data", data!)
                
                if let data = data as? [String : String] {
                    let label = UILabel()
                    label.text = data.description
                    label.numberOfLines = 0
                    label.textColor = .black
                    label.font = UIFont.systemFont(ofSize: 12)
                    
                    self.view.backgroundColor = .white
                    self.resultStack.addArrangedSubview(label)
                }
            } else {
                
                let alert = UIAlertController(title: "Message", message: "Document has no detectable barcode", preferredStyle: .alert)
            }*/
        }
        
        for image in self.images {
            
            let img = UIImageView(image: image)
            img.constraint(height: 250)
            self.resultStack.addArrangedSubview(img)
        }
        self.resultStack.addArrangedSubview(lbl)
        self.addCloseButton()
    }
    
    func showLoader() {
        
        backView = UIView(frame: self.view.frame)
        backView.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.view.addSubview(backView)
        
        let loader = UIActivityIndicatorView()
        loader.tintColor = .blue
        loader.color = .blue
        backView.addSubview(loader)
        loader.constraint(width: 40, height: 40)
        loader.centre(centerX: backView.centerXAnchor, centreY: backView.centerYAnchor)
        loader.startAnimating()
    }
    
    func formatDate(date: String) -> String {
        
        /*let inFormat = DateFormatter()
        inFormat.dateFormat = "dd-MM-yyyy"
        
        let outFormat = DateFormatter()
        inFormat.dateFormat = "yyyy-MM-dd"
        
        let dateObj = inFormat.date(from: date)
        
        if let dt = dateObj {
            return outFormat.string(from: dt)
        }else {
            return ""
        }*/
        
        let dates = date.split(separator: "-")
        let dt = dates.last! + "-" + dates[1] + "-" + dates.first!
        return String(dt)
    }

}
