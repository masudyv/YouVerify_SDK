//
//  ViewController.swift
//  YouVerify
//
//  Created by Masud Onikeku on 16/04/2024.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var logoImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setup()
    }
    
    func setup() {
        
        UIView.animate(withDuration: 0.5, animations: {[weak self] in
            
            self?.logoImage.alpha = 1
        }, completion: {[weak self] bool in
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
                
                let vc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "home") as! HomeViewController
                let nav = UINavigationController(rootViewController: vc)
                nav.hidesBarsOnTap = true
                nav.isNavigationBarHidden = true
                nav.modalPresentationStyle = .fullScreen
                self?.present(nav, animated: true)
            })
        })
    }


}

