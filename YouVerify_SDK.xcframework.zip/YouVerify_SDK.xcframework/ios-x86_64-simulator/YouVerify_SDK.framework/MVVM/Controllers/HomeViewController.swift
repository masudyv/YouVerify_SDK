//
//  HomeViewController.swift
//  YouVerify
//
//  Created by Masud Onikeku on 16/04/2024.
//

import UIKit
import AVFoundation
import Vision
import VisionKit
import SKCountryPicker

class HomeViewController: UIViewController {
    

    @IBOutlet weak var translucentView: UIView!
    @IBOutlet weak var xmark: UIImageView!
    @IBOutlet weak var idCardCapture: UIStackView!
    @IBOutlet weak var passportCapture: UIStackView!
    @IBOutlet weak var anyCardCapture: UIStackView!
    @IBOutlet weak var guideLineView: UIView!
    @IBOutlet weak var startScanningBtn: UIButton!
    @IBOutlet weak var translucentStack: UIStackView!
    
    @IBOutlet weak var idCaptureText: UILabel!
    @IBOutlet weak var HomeDescText: UILabel!
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var startView: UIView!
    @IBOutlet weak var startScanningLabel: UILabel!
    @IBOutlet weak var guidelineStack: UIStackView!
    @IBOutlet weak var seeGuidelinesLabel: UILabel!
    
    
    var captureSession: AVCaptureSession!
    var videoOutput: AVCaptureMovieFileOutput?
    var videoInput: AVCaptureDeviceInput?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    var captureDevice: AVCaptureDevice?
    var session: AVCaptureDevice.DiscoverySession?
    var captureDeviceVideoFound: Bool = false
    var country : Country? = nil
    var type : CaptureType? = nil
    var backView = UIView()
    var storyboardPickerView : CountryPickerView? = nil
    var callBack: (([String:Any]?) -> Void)? = nil
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        getFonts()
        setup()
        
    }
    
    func getFonts()  {

        let fileNames = ["BRSonoma-Regular", "BRSonoma-SemiBold"]
        let urls =  fileNames.map({ bd!.url(forResource: $0, withExtension: "otf")! })
        
        do {
            try urls.forEach({ try UIFont.register(from: $0) })
        } catch {
            print(error)
        }
        
        let font = UIFont(name: "BRSonoma-SemiBold", size: 17)
        boldFont = font!
        let font2 = UIFont(name: "BRSonoma-Regular", size: 12)
        regFont = font2!
        //font?.fontName = "BRSonoma-SemiBold"
        startScanningBtn.titleLabel?.font = font
        idCaptureText.font = font
        startScanningLabel.font = font
        seeGuidelinesLabel.font = font2
        HomeDescText.font = font2
    }
    
    @IBAction func guidelineBack(_ sender: UIButton) {
        
        guideLineView.alpha = 0
        hideTranslucentView()
        
    }
    
    @IBAction func StartScanning(_ sender: UIButton) {
        
        if self.type == CaptureType.id {
            let vc = VNDocumentCameraViewController()
            vc.delegate = self
            self.type = CaptureType.id
            self.present(vc, animated: true)
        }else if self.type == CaptureType.passport {
            self.type = CaptureType.passport
            /*CountryPickerWithSectionViewController.presentController(on: self.navigationController!, configuration: { countryController in
                countryController.configuration.flagStyle = .circular
                countryController.configuration.isCountryFlagHidden = false
                countryController.configuration.isCountryDialHidden = false
                countryController.favoriteCountriesLocaleIdentifiers = ["NG", "IN", "US", "ZA"]
                
            }) { [weak self] country in
                
                guard let self = self else { return }
                self.country = country
                //self.navigationController!.dism
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                    
                    let vc = VNDocumentCameraViewController()
                    vc.delegate = self
                    self.present(vc, animated: true)
                })
            }*/
            
            let vc = VNDocumentCameraViewController()
            vc.delegate = self
            self.present(vc, animated: true)
            
        }else {
            self.type = CaptureType.anyid
            CountryPickerWithSectionViewController.presentController(on: self.navigationController!, configuration: { countryController in
                countryController.configuration.flagStyle = .circular
                countryController.configuration.isCountryFlagHidden = false
                countryController.configuration.isCountryDialHidden = false
                countryController.favoriteCountriesLocaleIdentifiers = ["NG", "IN", "US", "ZA"]
                
            }) { [weak self] country in
                
                guard let self = self else { return }
                self.country = country
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                    
                    let vc = VNDocumentCameraViewController()
                    vc.delegate = self
                    self.present(vc, animated: true)
                })
            }
        }
        
        hideTranslucentView()
        guideLineView.alpha = 0
        
        //let font = UIFont.
        
    }
    
    func setup() {
        
        startScanningBtn.layer.cornerRadius = 8
        startView.layer.cornerRadius = 8
        
        startView.isUserInteractionEnabled = true
        startView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(showTranslucentView)))
        
        xmark.isUserInteractionEnabled = true
        xmark.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideTranslucentView)))
        
        idCardCapture.isUserInteractionEnabled = true
        idCardCapture.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(navCapture)))
        
        passportCapture.isUserInteractionEnabled = true
        passportCapture.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(navCapture)))
        
        anyCardCapture.isUserInteractionEnabled = true
        anyCardCapture.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(navCapture)))
        
        for vws in guidelineStack.arrangedSubviews {
            
            if let vws = vws as? UIStackView {
                
                //print(vws.arrangedSubviews)
                
                for vvs in vws.arrangedSubviews {
                    
                    if let vvs = vvs as? UIStackView {
                        let first = vvs.arrangedSubviews.first as? UILabel
                        first?.font = boldFont
                        
                        let second = vvs.arrangedSubviews.last as? UILabel
                        second?.font = regFont
                    }
                }
            }
        }
        
        for vws in translucentStack.arrangedSubviews {
            
            if let vws = vws as? UIStackView {
                
                //print(vws.arrangedSubviews)
                
                for vvs in vws.arrangedSubviews {
                    
                    if let vvs = vvs as? UILabel {
                        vvs.font = boldFont
                    }
                }
            }
        }
    }
    
    @objc func showTranslucentView() {
        
        UIView.animate(withDuration: 0.5, animations: {[weak self] in
            
            self?.translucentView.alpha = 1
            //self?.startView.alpha = 0
            self?.xmark.alpha = 1
        })
    }
    
    @objc func navCapture(_ sender: UITapGestureRecognizer) {
        
        /*let vc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "capture") as! CaptureViewController
        if sender.view == idCardCapture {
            vc.type = CaptureType.id
            
        }else if sender.view == passportCapture {
            vc.type == CaptureType.passport
        }else {
            vc.type == CaptureType.anyid
        }
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)*/
        
        if let view = sender.view {
            
            if view == idCardCapture {
                self.type = CaptureType.id
            }else if view == passportCapture {
                self.type = CaptureType.passport
            }else {
                self.type = CaptureType.anyid
            }
        }
        
        UIView.animate(withDuration: 0.5, animations: {[weak self] in
            
            self?.translucentView.alpha = 0
            self?.guideLineView.alpha = 1
            self?.xmark.alpha = 0
        })
        
    }
    
    @objc func hideTranslucentView() {
        
        UIView.animate(withDuration: 0.5, animations: {[weak self] in
            
            self?.translucentView.alpha = 0
            //self?.startView.alpha = 1
            self?.xmark.alpha = 0
        })
    }
    
    
}

extension HomeViewController : VNDocumentCameraViewControllerDelegate {
    
    public func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
        
        let images = extractImages(from: scan)
        controller.dismiss(animated: true)
        
        let vc = YVStoryBoard.instantiateViewController(withIdentifier: "result") as! ResultViewController
        self.navigationController?.isNavigationBarHidden = true
        self.navigationController?.isToolbarHidden = true
        //self.navigationController?.hid = true
        vc.callBack = self.callBack
        vc.images = images
        if type == CaptureType.id || type == CaptureType.anyid {
            if images.count < 2 {
                self.showAlert2(msg: "Please scan front and back of document", actions: {
                    self.present(controller, animated: true)
                })
            }else if images.count > 2 {
                self.showAlert2(msg: "Scans should only contain front and back of document", actions: {
                    self.present(controller, animated: true)
                })
            }else {
                //controller.dismiss(animated: true)
                vc.type = self.type
                vc.county = self.country
                self.navigationController!.pushViewController(vc, animated: true)
                
            }
        }else {
            if images.count < 1 {
                self.showAlert2(msg: "Please scan data page of document", actions: {
                    self.present(controller, animated: true)
                })
            }else if images.count > 1 {
                self.showAlert2(msg: "Scan should only contain the data page of document", actions: {
                    self.present(controller, animated: true)
                })
            }else {
                //controller.dismiss(animated: true)
                vc.type = self.type
                vc.county = self.country
                self.navigationController!.pushViewController(vc, animated: true)
                
            }
        }
        
    }
    
    func extractImages(from scan: VNDocumentCameraScan) -> [UIImage] {
        var extractedImages = [UIImage]()
        for index in 0..<scan.pageCount {
            let extractedImage = scan.imageOfPage(at: index)
            guard let cgImage = extractedImage.cgImage else { continue }
            
            extractedImages.append(UIImage(cgImage: cgImage))
        }
        return extractedImages
    }
    
    
}

//extension HomeViewController : Delegate


