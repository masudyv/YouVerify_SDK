//
//  CaptureViewModel.swift
//  YouVerify
//
//  Created by Masud Onikeku on 24/04/2024.
//

import Foundation
import SwiftyJSON

class CaptureViewModel {
    
    
    var uploadDone : Observable<Response?> = Observable(nil)
    var postCaptureDone : Observable<Response?> = Observable(nil)
    var fileUploadDone : Observable<Response?> = Observable(nil)
    
    
    func sendComms(body: [String:Any]) {
        
        Service.requestData(url: "v1/sdk/identity/document-capture/ocr", method: .post, parameters: body, completion: {[weak self] result in
            
            
            switch result{
            case .success(let jsonData):
                let jsonResult = JSON(jsonData)
                self?.uploadDone.value = Response(check: true, description: "", object: jsonResult)
            case .failure(let failure):
                print("failure", failure)
                switch failure {
                case .unknownError(let string):
                    self?.uploadDone.value = Response(check: false, description: string, object: nil)
                default:
                    self?.uploadDone.value = Response(check: false, description: "Error in reading document", object: nil)
                }
            }
        })
    }
    
    func sendPostCapture(body: [String:Any]) {
        
        Service.requestData(url: "v1/sdk/identity/document-capture", method: .post, parameters: body, completion: {[weak self] result in
            
            
            switch result{
            case .success(let jsonData):
                let jsonResult = JSON(jsonData)
                self?.postCaptureDone.value = Response(check: true, description: "", object: jsonResult)
            case .failure(let failure):
                print(failure)
                switch failure {
                case .unknownError(let string):
                    self?.postCaptureDone.value = Response(check: false, description: string, object: nil)
                default:
                    self?.postCaptureDone.value = Response(check: false, description: "Error in reading document", object: nil)
                }
            }
        })
    }
    
    func uploadImage(body: [String:String], dataArray: [(Data, String)]) {
        
        Service.sessionDataWithHeaderwithFile(url: "v1/uploads/media", method: .post, parameters: body, arrImages: dataArray, completion: {[weak self] result in
            
            
            switch result{
            case .success(let jsonData):
                let jsonResult = JSON(jsonData)
                self?.fileUploadDone.value = Response(check: true, description: "", object: jsonResult["data"].arrayObject!)
            case .failure(let failure):
                print(failure)
                switch failure {
                case .unknownError(let string):
                    self?.fileUploadDone.value = Response(check: false, description: string, object: nil)
                default:
                    self?.fileUploadDone.value = Response(check: false, description: "Error uploading image", object: nil)
                }
            }
        })
    }
    
}
